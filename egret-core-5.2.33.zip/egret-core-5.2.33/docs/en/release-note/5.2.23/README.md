# Egret Engine 5.2.23 Release Notes
The Egret Engine released the 5.2.23 stable version on July 9, 2019.

## 2D Rendering - JavaScript 
- **[optimize]** On the PC browser, the fps panel and the log information panel, add `id`: `egret-fps-panel`, which can be hidden and displayed by code.
- **[optimize]** Optimize the release logic in `vivogame.ts`
- **[fix]** Fix spelling errors in the `setFontFamily` method in `eui.Label`
