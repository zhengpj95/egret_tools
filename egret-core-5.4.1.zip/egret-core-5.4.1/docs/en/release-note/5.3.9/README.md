# Egret Engine 5.3.9 Release Notes
The Egret Engine released the 5.3.9 version on September 9 2020.

## 2D Rendering - JavaScript 
- **[NEW]**  Support the release of huawei fastgame
- **[FIX]** Fix the problem of blurry display in webgl mode
- **[FIX]** Fix the problem that the 360 mini game export dragonbones library failed
