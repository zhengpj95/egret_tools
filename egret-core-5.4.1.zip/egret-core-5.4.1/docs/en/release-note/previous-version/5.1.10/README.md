# Egret Engine 5.1.10 Release Notes


---


The Egret Engine officially released version 5.1 in December 2017. On April 23, 2018, we will release version 5.1.10. This release is a centralized bug fix for version 5.1.



## 2D Rendering - JavaScript

* Fix the issue of removing subsequent objects when BitmapData is removed
* Repair server started by egret startserver can read files outside the project

## AssetsManager
* Fix the issue of using loadGroup

## Third-party libraries
* Add Matchvs game cloud
* Add youmi SDK