# Egret Engine 5.2.33 Release Notes
The Egret Engine released the 5.2.33 stable version on December 30, 2019.

- **[NEW]** Support release into Alipay mini games

## vivo Game v0.2.14
- **[OPTIMIZE]**  window.WebGLRenderingContext method is not supported on vivo platform, remove related references
