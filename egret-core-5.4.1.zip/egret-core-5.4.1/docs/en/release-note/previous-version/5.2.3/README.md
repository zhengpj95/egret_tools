# Egret Engine 5.2.3 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On June 19, 2018, we will release a stable version of 5.2.3. This release is a centralized bug fix for version 5.2



## Command Line

* 修复```egret run```命令无法正常打开新版微信开发者工具问题

## Third-party libraries

* matchvs library upgrade to 3.7.2.1

## WeChat Games Support Library

WeChat Mini Game Support Library Please update your project with the release of a WeChat minigame by Egret Launcher. Version number 1.1.2

* Use `````wxBindCanvasTexture``` to significantly improve sub-domain rendering efficiency