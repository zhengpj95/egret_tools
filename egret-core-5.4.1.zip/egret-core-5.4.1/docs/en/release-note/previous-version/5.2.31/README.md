# Egret Engine 5.2.31 Release Notes
The Egret Engine released the 5.2.31 stable version on November 14, 2019.

- **[NEW]** [Support for WeChat engine plugin](http://developer.egret.com/cn/github/egret-docs/Engine2D/minigame/useWxPlugin/index.html)
