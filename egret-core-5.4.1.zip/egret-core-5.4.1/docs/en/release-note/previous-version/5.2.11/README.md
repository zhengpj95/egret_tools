# Egret Engine 5.2.11 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On October 15, 2018, we will release a stable version of 5.2.11. This release is a centralized bug fix for version 5.2


## Command Line

* Fix release bricks manifest exception problem
* After modifying tsconfig.json and egretProperties.json, the server opened by egret run -a is automatically closed.
* Fix the egret run command port exception problem