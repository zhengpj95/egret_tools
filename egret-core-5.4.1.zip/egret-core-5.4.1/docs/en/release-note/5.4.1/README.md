# Egret Engine 5.4.1 Release Notes
The Egret Engine released the 5.4.1 version on March 4 2021.

## 2D Rendering - JavaScript 
- **[FIX]** Fix the problem of unable to enter text
- **[FIX]** Fix the problem of abnormal calculation of custom font width
- **[FIX]** The input box will change with the scale value when inputting
- **[FIX]** Fix the problem that when eui group is nested, a scale of 0 will trigger a full-screen click
- **[FIX]** Fix the problem that eui scroller is nested and the memory cannot be released when the click event is triggered
- **[FIX]** Fix the issue that DragonBones level changes are invalid