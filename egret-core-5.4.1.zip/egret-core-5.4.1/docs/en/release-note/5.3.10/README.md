# Egret Engine 5.3.10 Release Notes
The Egret Engine released the 5.3.10 version on September 25 2020.

## 2D Rendering - JavaScript 
- **[NEW]** Support the taobao creative app
- **[FIX]** Fix the problem with mesh Caton on the ios14 system.
- **[FIX]** Fixes an issue that cannot be returned after the htmlsound is mounted to the background.
- **[FIX]** Fixes an abnormal problem with the dragonbones model.
